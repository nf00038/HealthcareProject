from django import forms

class AtrialFibrillationSymptomsForm(forms.Form):
    palpitations = forms.CharField()
    weakness = forms.CharField()
    reducedexercise = forms.CharField()
    fatigue = forms.CharField()
    lightheadedness = forms.CharField()
    dizziness = forms.CharField()
    chestpain = forms.CharField()

class AtrialFibrillationSituationsForm(forms.Form):
    ExerciseInduced = forms.CharField()
    OccupationalInduced = forms.CharField()
    AllergyInduced = forms.CharField()



