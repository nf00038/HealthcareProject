ATRIALFIBRILLATION_POSITIVE_SYMPTOMS = [

    ("1", "No Palpitations"),
    ("2", "No Weakness"),
    ("3", "Improved ability to Exercise"),
    ("4", "No Fatigue"),
    ("5", "No Lightheadedness"),
    ("6", "No Dizziness"),
    ("7", "No Shortness of Breath"),
    ("8", "No Chest Pain"),

    ]

ATRIALFIBRILLATION_NEGATIVE_SYMPTOMS = [
    
    ("1", "Palpitations"),
    ("2", "Weakness"),
    ("3", "Reduced Ability to Exercise"),
    ("4", "Fatigue"),
    ("5", "Lightheadedness"),
    ("6", "Dizziness"),
    ("7", "Shortness of breath"),
    ("8", "Chest pain"),
    
    ]
