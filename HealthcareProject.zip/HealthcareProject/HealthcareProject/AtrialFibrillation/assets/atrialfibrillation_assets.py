from django.db import models

class Assets(models.Model):
    Asset_Category = models.CharField(max_length='255')
    Asset_Subcategory = models.CharField(max_length='255')
    Asset_Description = models.CharField(max_length='255')
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class Asset_Purchase(models.Model):
    date_of_purchase = models.DateField()
    asset_age = models.CharField(max_length='255')
    asset_purchase_value = models.CharField(max_length='255')
    asset_purchase_currency = models.CharField(max_length='255')
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class Asset_Transfer(models.Model):
    date_of_transfer = models.DateField()
    asset_age = models.CharField(max_length='255')
    asset_transfer_value = models.CharField(max_length='255')
    asset_transfer_currency = models.CharField(max_length='255')
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class Asset_Sale(models.Model):
    date_of_sale = models.DateField()
    asset_age = models.CharField(max_length='255')
    asset_sale_value = models.CharField(max_length='255')
    asset_sale_currency = models.CharField(max_length='255')
    asset_description = models.CharField(max_length='255')
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)