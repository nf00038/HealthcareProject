from django.apps import AppConfig


class Atrial_FibrillationConfig(AppConfig):
    name = 'Atrial_Fibrillation'
