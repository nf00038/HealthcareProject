CVD_NEGATIVE_SYMPTOMS = [
    
    ("1", "Pain or pressure in the chest, which may indicate angina"),
    ("2", "Pain or discomfort in the arms, left shoulder, elbows, jaw or back"),
    ("3", "Shortness of breath"),
    ("4", "Nausea and Fatigue"),
    ("5", "Lightheadedness or Dizziness"),
    ("6", "Cold sweats"),
    
    ],

CVD_POSITIVE_SYMPTOMS = [
    
    ("1", "1"),

    ]
