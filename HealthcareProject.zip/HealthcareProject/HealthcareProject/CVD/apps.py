from django.apps import AppConfig


class CVDConfig(AppConfig):
    name = 'CVD'
