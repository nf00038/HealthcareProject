class CHD_Echocardiogram(models.Model):
    ECG1_Value = models.IntegerField()
    ECG2_Value = models.IntegerField()
    ECG3_Value = models.IntegerField()
    ECG4_Value = models.IntegerField()
    ECG5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class CHD_ExerciseStressTests(models.Model):
    EST1_Value = models.IntegerField()
    EST2_Value = models.IntegerField()
    EST3_Value = models.IntegerField()
    EST4_Value = models.IntegerField()
    EST5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class CHD_Xrays(models.Model):
    Xray1_Value = models.IntegerField()
    Xray2_Value = models.IntegerField()
    Xray3_Value = models.IntegerField()
    Xray4_Value = models.IntegerField()
    Xray5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class CHD_Echocardiogram(models.Model):
    EC1_Value = models.IntegerField()
    EC2_Value = models.IntegerField()
    EC3_Value = models.IntegerField()
    EC4_Value = models.IntegerField()
    EC5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class CHD_BloodTests(models.Model):
    BT1_Value = models.IntegerField()
    BT2_Value = models.IntegerField()
    BT3_Value = models.IntegerField()
    BT4_Value = models.IntegerField()
    BT5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class coronary_angiography(models.Model):
    CA1_Value = models.IntegerField()
    CA2_Value = models.IntegerField()
    CA3_Value = models.IntegerField()
    CA4_Value = models.IntegerField()
    CA5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class radionuclide_tests(models.Model):
    RNT1_Value = models.IntegerField()
    RNT2_Value = models.IntegerField()
    RNT3_Value = models.IntegerField()
    RNT4_Value = models.IntegerField()
    RNT5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class MRI_scans(models.Model):
    MRI1_Value = models.IntegerField()
    MRI2_Value = models.IntegerField()
    MRI3_Value = models.IntegerField()
    MRI4_Value = models.IntegerField()
    MRI5_value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class CT_scans(models.Model):
    CT1_Scan = models.IntegerField()
    CT2_Scan = models.IntegerField()
    CT3_Scan = models.IntegerField()
    CT4_Scan = models.IntegerField()
    CT5_Scan = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')