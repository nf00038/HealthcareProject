from django.apps import AppConfig


class Blood_PressureConfig(AppConfig):
    name = 'Blood_Pressure'
