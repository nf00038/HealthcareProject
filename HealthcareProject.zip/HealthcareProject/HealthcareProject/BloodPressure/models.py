from django.db import models
from HealthcareProject.BloodPressure.symptoms.symptom_choices import BLOODPRESSURE_POSITIVE_SYMPTOMS, BLOODPRESSURE_NEGATIVE_SYMPTOMS
from HealthcareProject.Healthcare.frequency_choices import FREQUENCY_CHOICES
# Create your models here.

class medications(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    purpose = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.CharField(max_length=255)
    measurement = models.CharField(max_length=255)
    date_created = models.DateField()
    date_updated = models.DateField()

class ingredients(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    purpose = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.CharField(max_length=255)
    measurement = models.CharField(max_length=255)
    date_created = models.DateField()
    date_updated = models.DateField()

class BloodPressure_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=BLOODPRESSURE_POSITIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=BLOODPRESSURE_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class Admissions(models.Model):
    date_of_admission = models.DateField()
    patient_age = models.CharField()
    patient_gender = models.CharField()
    patient_education = models.CharField()
    patient_postcode = models.CharField()
    patient_temperature = models.CharField()
    patient_heartrate = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)



class Asset_Purchase(models.Model):
    date_of_purchase = models.DateField()
    asset_age = models.CharField()
    asset_purchase_value = models.CharField()
    asset_purchase_currency = models.CharField()
    #User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Asset_Transfer(models.Model):
    date_of_transfer = models.DateField()
    asset_age = models.CharField()
    asset_transfer_value = models.CharField()
    asset_transfer_currency = models.CharField()
    #User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Asset_Sale(models.Model):
    date_of_sale = models.DateField()
    asset_age = models.CharField()
    asset_sale_value = models.CharField()
    asset_sale_currency = models.CharField()
    asset_description = models.CharField()
    #User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Treatments(models.Model):
    Treatment_Name = models.CharField()
    Treatment_Desc = models.CharField()
    Treatment_Type = models.CharField()
    Treament_Method = models.CharField()
    Treatment_Intensity = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)
