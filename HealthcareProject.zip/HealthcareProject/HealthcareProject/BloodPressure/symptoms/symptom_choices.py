BLOODPRESSURE_POSITIVE_SYMPTOMS = [
    
    ("1", "No Headaches"),
    ("2", "No Shortness of Breath"),
    ("3", "No Nosebleeds"),
    ("4", "No Flushing"),
    ("5", "No Dizziness"),
    ("6", "No Chest Pain"),
    ("7", "No Visual Changes"),
    ("8", "No Blood in the urine"),

    
    ]

BLOODPRESSURE_NEGATIVE_SYMPTOMS = [
    
    ("1", "Headaches"),
    ("2", "Shortness of Breath"),
    ("3", "Nosebleeds"),
    ("4", "Flushing"),
    ("5", "Dizziness"),
    ("6", "Chest Pain"),
    ("7", "Visual Changes"),
    ("8", "Blood in the urine"),
    
    ]
