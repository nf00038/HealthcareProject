from django import forms

class BloodPressureSymptomsForm(forms.Form):
    headaches = forms.CharField()
    shortnessofbreath = forms.CharField()
    nosebleeds = forms.CharField()
    flushing = forms.CharField()
    dizziness = forms.CharField()
    chestpain = forms.CharField()
    visualchanges = forms.CharField()
    bloodurine = forms.CharField()

class BloodPressureSituationsForm(forms.Form):
    ExerciseInduced = forms.CharField()
    OccupationalInduced = forms.CharField()
    AllergyInduced = forms.CharField()




