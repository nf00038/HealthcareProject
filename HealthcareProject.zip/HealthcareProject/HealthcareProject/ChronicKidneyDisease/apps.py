from django.apps import AppConfig


class Chronic_Kidney_DiseaseConfig(AppConfig):
    name = 'Chronic_Kidney_Disease'
