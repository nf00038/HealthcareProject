class bloodtest(models.Model):
    BT1_Value = models.IntegerField()
    BT2_Value = models.IntegerField()
    BT3_Value = models.IntegerField()
    BT4_Value = models.IntegerField()
    BT5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class urinetest(models.Model):
    UT1_Value = models.IntegerField()
    UT2_Value = models.IntegerField()
    UT3_Value = models.IntegerField()
    UT4_Value = models.IntegerField()
    UT5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')


