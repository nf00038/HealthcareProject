CKD_Negative_Symptoms = [
    
    ("1", "Weight loss and poor appetite"),
    ("2", "Swollen ankles, feet or hands, as a result of water retention"),
    ("3", "Shortness of breath"),
    ("4", "Tiredness"),
    ("5", "Blood in your pee"),
    ("6", "An inreased need to pee especially at night"),
    ("7", "Difficulty sleeping (insomnia)"),
    ("8", "Itchy skin"),
    
    ],

CKD_POSITIVE_SYMPTOMS = [
    
    ("1","1"),
    
    ]
