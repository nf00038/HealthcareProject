from django.db import models
from HealthcareProject.Cancer.symptoms.symptom_choices import BREAST_CANCER_NEGATIVE_SYMPTOMS, BREAST_CANCER_POSITIVE_SYMPTOMS, BLADDER_CANCER_NEGATIVE_SYMPTOMS, BLADDER_CANCER_POSITIVE_SYMPTOMS, BOWEL_CANCER_NEGATIVE_SYMPTOMS, BOWEL_CANCER_POSITIVE_SYMPTOMS, STOMACH_CANCER_NEGATIVE_SYMPTOMS, STOMACH_CANCER_POSITIVE_SYMPTOMS, MOUTH_CANCER_NEGATIVE_SYMPTOMS, MOUTH_CANCER_POSITIVE_SYMPTOMS, BRAIN_CANCER_NEGATIVE_SYMPTOMS, BRAIN_CANCER_POSITIVE_SYMPTOMS, SKIN_CANCER_NEGATIVE_SYMPTOMS, SKIN_CANCER_POSITIVE_SYMPTOMS
from HealthcareProject.Healthcare.frequency_choices import FREQUENCY_CHOICES
# Create your models here.

class medications(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    purpose = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.CharField(max_length=255)
    measurement = models.CharField(max_length=255)
    date_created = models.DateField()
    date_updated = models.DateField()

class ingredients(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    purpose = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.CharField(max_length=255)
    measurement = models.CharField()
    date_created = models.DateField()
    date_updated = models.DateField()

class BreastCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BreastCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=BREAST_CANCER_NEGATIVE_CHOICES)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=BREAST_CANCER_NEGATIVE_CHOICES)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BladderCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BladderCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=BLADDER_CANCER_POSITIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=BLADDER_CANCER_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BowelCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BowelCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=BOWEL_CANCER_POSITIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=BOWEL_CANCER_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class StomachCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class StomachCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=STOMACH_CANCER_POSITIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=STOMACH_CANCER_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class MouthCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class MouthCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=MOUTH_CANCER_POSITIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=MOUTH_CANCER_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BrainCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class BrainCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=BRAIN_CANCER_NEGATIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=BRAIN_CANCER_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class SkinCancer_Causes(models.Model):
    Positive = models.CharField()
    Positive_Frequency = models.CharField()
    Positive_Frequency_Category = models.CharField()
    Date = models.DateField()
    Negative = models.CharField()
    Negative_Frequency = models.CharField()
    Negative_Frequency_Category = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class SkinCancer_Symptoms(models.Model):
    Positive = models.CharField(max_length=255, choices=SKIN_CANCER_POSITIVE_SYMPTOMS)
    Positive_Frequency = models.IntegerField(max_length=3)
    Positive_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    Negative = models.CharField(max_length=255, choices=SKIN_CANCER_NEGATIVE_SYMPTOMS)
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length=255, choices=FREQUENCY_CHOICES)
    Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Admissions(models.Model):
    date_of_admission = models.DateField()
    patient_age = models.CharField()
    patient_gender = models.CharField()
    patient_education = models.CharField()
    patient_postcode = models.CharField()
    patient_temperature = models.CharField()
    patient_heartrate = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Asset_Purchase(models.Model):
    date_of_purchase = models.DateField()
    asset_age = models.CharField()
    asset_purchase_value = models.CharField()
    asset_purchase_currency = models.CharField()
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Asset_Transfer(models.Model):
    date_of_transfer = models.DateField()
    asset_age = models.CharField()
    asset_transfer_value = models.CharField()
    asset_transfer_currency = models.CharField()
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Asset_Sale(models.Model):
    date_of_sale = models.DateField()
    asset_age = models.CharField()
    asset_sale_value = models.CharField()
    asset_sale_currency = models.CharField()
    asset_description = models.CharField()
    User = models.ForeignKey()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


class Treatments(models.Model):
    Treatment_Name = models.CharField()
    Treatment_Desc = models.CharField()
    Treatment_Type = models.CharField()
    Treament_Method = models.CharField()
    Treatment_Intensity = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)
