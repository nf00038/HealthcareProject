BREAST_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "Lump or firm feeling in your breast or under your arm"),
    ("2", "Nipple changes or discharge"),
    ("3", "Skin that is itchy, red, scaly, dimpled or puckered"),
    ("4", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("5", "Weight gain or weight loss for no known reason"),
    
    ],

BREAST_CANCER_POSITIVE_SYMPTOMS = [
      
    ("1","1")
    
    ]

BLADDER_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "Trouble urinating"),
    ("2", "Pain when urinating"),
    ("3", "Blood in the urine"),
    ("4", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("5", "Weight gain or weight loss for no known reason"),
    
    ],

BLADDER_CANCER_POSITIVE_SYMPTOMS = [
     
    ("1", "1")
    
    ],

BOWEL_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "Blood in the stools"),
    ("2", "Changes in bowel habits"),
    ("3", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("4", "Weight gain or weight loss for no known reason"),

    ],

BOWEL_CANCER_POSITIVE_SYMPTOMS = [
       
    ("1", "1")
    
    ]

STOMACH_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "Pain after eating"),
    ("2", "Trouble swallowing"),
    ("3", "Belly pain"),
    ("4", "Nausea and Vomiting"),
    ("5", "Appetite Changes"),
    ("6", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("7", "Weight gain or weight loss for no known reason"),
    
    ],

STOMACH_CANCER_POSITIVE_SYMPTOMS = [
       
    ("1", "1"),
    
    ]

MOUTH_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "A white or red patch on the tongue in your mouth"),
    ("2", "Bleeding, pain or numbness in the lip or mouth"),
    ("3", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("4", "Weight gain or weight loss for no known reason"),
    
    ],

MOUTH_CANCER_POSITIVE_SYMPTOMS = [
      
    
    ("1", "1"),
    
    ],

BRAIN_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "Headaches"),
    ("2", "Seizures"),
    ("3", "Vision changes"),
    ("4", "Hearing changes"),
    ("5", "Drooping of the face"),
    ("6", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("7", "Weight gain or weight loss for no known reason"),

    ],

BRAIN_CANCER_POSITIVE_SYMPTOMS = [
                                  
    ("1", "1"),


    ],

SKIN_CANCER_NEGATIVE_SYMPTOMS = [
    
    ("1", "A flesh coloured lump that bleeds or turns scaly"),
    ("2", "A new mole or a change in an existing mole"),
    ("3", "A sore that does not heal"),
    ("4", "Jaundice (yellowing of the skin or the whites of the eyes)"),
    ("5", "Swelling or lumps anywhere such as in the neck, underarm, stomach and groin"),
    ("6", "Weight gain or weight loss for no known reason"),

    ],

SKIN_CANCER_POSITIVE_SYMPTOMS = [
     
    ("1", "1"),
    
    ]

