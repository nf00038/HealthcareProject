class medications(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    purpose = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.CharField(max_length=255)
    measurement = models.CharField(max_length=255)
    date_created = models.DateField()
    date_updated = models.DateField()

class ingredients(models.Model):
    name = models.CharField(max_length=255)
    description = models.CharField(max_length=255)
    purpose = models.CharField(max_length=255)
    type = models.CharField(max_length=255)
    quantity = models.CharField(max_length=255)
    measurement = models.CharField()
    date_created = models.DateField()
    date_updated = models.DateField()