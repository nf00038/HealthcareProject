from django import forms

class BariumXrayForm(forms.Form):
    BX1 = forms.CharField()
    BX2 = forms.CharField()
    BX3 = forms.CharField()
    BX4 = forms.CharField()
    BX5 = forms.CharField()

class BloodTestForm(forms.Form):
    BT1 = forms.CharField()
    BT2 = forms.CharField()
    BT3 = forms.CharField()
    BT4 = forms.CharField()
    BT5 = forms.CharField()

class BoneDensityScan(forms.Form):
    BDS1 = forms.CharField()
    BDS2 = forms.CharField()
    BDS3 = forms.CharField()
    BDS4 = forms.CharField()
    BDS5 = forms.CharField()

class BoneMarrowTest(forms.Form):
    BMT1 = forms.CharField()
    BMT2 = forms.CharField()
    BMT3 = forms.CharField()
    BMT4 = forms.CharField()
    BMT5 = forms.CharField()

class BoneScan(forms.Form):
    BS1 = forms.CharField()
    BS2 = forms.CharField()
    BS3 = forms.CharField()
    BS4 = forms.CharField()
    BS5 = forms.CharField()

class CTColonoscopy(forms.Form):
    CTC1 = forms.CharField()
    CTC2 = forms.CharField()
    CTC3 = forms.CharField()
    CTC4 = forms.CharField()
    CTC5 = forms.CharField()

class CTScan(forms.Form):
    CTS1 = forms.CharField()
    CTS2 = forms.CharField()
    CTS3 = forms.CharField()
    CTS4 = forms.CharField()
    CTS5 = forms.CharField()

class CTUrogram(forms.Form):
    CTU1 = forms.CharField()
    CTU2 = forms.CharField()
    CTU3 = forms.CharField()
    CTU4 = forms.CharField()
    CTU5 = forms.CharField()

class CapsuleEndoscopy(forms.Form):
    CE1 = forms.CharField()
    CE2 = forms.CharField()
    CE3 = forms.CharField()
    CE4 = forms.CharField()
    CE5 = forms.CharField()

class Colonoscopy(forms.Form):
    C1 = forms.CharField()
    C2 = forms.CharField()
    C3 = forms.CharField()
    C4 = forms.CharField()
    C5 = forms.CharField()

class Cystoscopy(forms.Form):
    CYS1 = forms.CharField()
    CYS2 = forms.CharField()
    CYS3 = forms.CharField()
    CYS4 = forms.CharField()
    CYS5 = forms.CharField()

class Dermoscopy(forms.Form):
    DS1 = forms.CharField()
    DS2 = forms.CharField()
    DS3 = forms.CharField()
    DS4 = forms.CharField()
    DS5 = forms.CharField()

class ERCP(forms.Form):
    ERCP1 = forms.CharField()
    ERCP2 = forms.CharField()
    ERCP3 = forms.CharField()
    ERCP4 = forms.CharField()
    ERCP5 = forms.CharField()

class Endoscopy(forms.Form):
    E1 = forms.CharField()
    E2 = forms.CharField()
    E3 = forms.CharField()
    E4 = forms.CharField()
    E5 = forms.CharField()

class FISH(forms.Form):
    F1 = forms.CharField()
    F2 = forms.CharField()
    F3 = forms.CharField()
    F4 = forms.CharField()
    F5 = forms.CharField()

class Flexible_Sigmoidoscopy(forms.Form):
    FS1 = forms.CharField()
    FS2 = forms.CharField()
    FS3 = forms.CharField()
    FS4 = forms.CharField()
    FS5 = forms.CharField()

class Gastroscopy(forms.Form):
    G1 = forms.CharField()
    G2 = forms.CharField()
    G3 = forms.CharField()
    G4 = forms.CharField()
    G5 = forms.CharField()

class IVU(forms.Form):
    IVU1 = forms.CharField()
    IVU2 = forms.CharField()
    IVU3 = forms.CharField()
    IVU4 = forms.CharField()
    IVU5 = forms.CharField()

class LumbarPuncture(forms.Form):
    LP1 = forms.CharField()
    LP2 = forms.CharField()
    LP3 = forms.CharField()
    LP4 = forms.CharField()
    LP5 = forms.CharField()

class MIBG(forms.Form):
    MIBG1 = forms.CharField()
    MIBG2 = forms.CharField()
    MIBG3 = forms.CharField()
    MIBG4 = forms.CharField()
    MIBG5 = forms.CharField()

class MRI(forms.Form):
    MRI1 = forms.CharField()
    MRI2 = forms.CharField()
    MRI3 = forms.CharField()
    MRI4 = forms.CharField()
    MRI5 = forms.CharField()

class Mammogram(forms.Form):
    MM1 = forms.CharField()
    MM2 = forms.CharField()
    MM3 = forms.CharField()
    MM4 = forms.CharField()
    MM5 = forms.CharField()

class Mediastinoscopy(forms.Form):
    MS1 = forms.CharField()
    MS2 = forms.CharField()
    MS3 = forms.CharField()
    MS4 = forms.CharField()
    MS5 = forms.CharField()

class Neuroendoscopy(forms.Form):
    NEU1 = forms.CharField()
    NEU2 = forms.CharField()
    NEU3 = forms.CharField()
    NEU4 = forms.CharField()
    NEU5 = forms.CharField()

class PETScan(forms.Form):
    PET1 = forms.CharField()
    PET2 = forms.CharField()
    PET3 = forms.CharField()
    PET4 = forms.CharField()
    PET5 = forms.CharField()

class PETCTScan(forms.Form):
    PETCT1 = forms.CharField()
    PETCT2 = forms.CharField()
    PETCT3 = forms.CharField()
    PETCT4 = forms.CharField()
    PETCT5 = forms.CharField()

class PETMRIScan(forms.Form):
    PETMRI1 = forms.CharField()
    PETMRI2 = forms.CharField()
    PETMRI3 = forms.CharField()
    PETMRI4 = forms.CharField()
    PETMRI5 = forms.CharField()

class Pericardioscopy(forms.Form):
    PERI1 = forms.CharField()
    PERI2 = forms.CharField()
    PERI3 = forms.CharField()
    PERI4 = forms.CharField()
    PERI5 = forms.CharField()

class UltrasoundScan(forms.Form):
    ULTRA1 = forms.CharField()
    ULTRA2 = forms.CharField()
    ULTRA3 = forms.CharField()
    ULTRA4 = forms.CharField()
    ULTRA5 = forms.CharField()

class Xray(forms.Form):
    XRAY1 = forms.CharField()
    XRAY2 = forms.CharField()
    XRAY3 = forms.CharField()
    XRAY4 = forms.CharField()
    XRAY5 = forms.CharField()