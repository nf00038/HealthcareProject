class physicalexamination(models.Model):
    PE_Value1 = models.IntegerField()
    PE_Value2 = models.IntegerField()
    PE_Value3 = models.IntegerField()
    PE_Value4 = models.IntegerField()
    PE_Value5 = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class laboratorytests(models.Model):
    LT1 = models.IntegerField()
    LT2 = models.IntegerField()
    LT3 = models.IntegerField()
    LT4 = models.IntegerField()
    LT5 = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class imagingtests(models.Model):
    IT1 = models.IntegerField()
    IT2 = models.IntegerField()
    IT3 = models.IntegerField()
    IT4 = models.IntegerField()
    IT5 = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class Biopsy(models.Model):
    BT1 = models.IntegerField()
    BT2 = models.IntegerField()
    BT3 = models.IntegerField()
    BT4 = models.IntegerField()
    BT5 = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')
