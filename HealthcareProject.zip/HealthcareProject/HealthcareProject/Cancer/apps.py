from django.apps import AppConfig


class CancerConfig(AppConfig):
    name = 'Cancer'
