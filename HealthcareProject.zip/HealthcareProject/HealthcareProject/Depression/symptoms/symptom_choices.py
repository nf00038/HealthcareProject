DEPRESSION_PSYCHOLOGICAL_NEGATIVE_SYMPTOMS = [
    
    ("1", "Continuous low mood or sadness"),
    ("2", "Feeling hopeless and helpless"),
    ("3", "Having low self esteem"),
    ("4", "Feeling tearful"),
    ("5", "Feeling guilt ridden"),
    ("6", "Feeling irritable and/or intolerant of others"),
    ("7", "Having no interest or motivation in things"),
    ("8", "Finding it difficult to make decisions"),
    ("9", "Not getting any enjoyment out of life"),
    ("10", "Feeling anxious or worried"),
    ("11", "Having suicidal thoughts or thoughts of harming yourself"),
    
    ],

DEPRESSION_PSYCHOLOGICAL_POSITIVE_SYMPTOMS = [
    
    ("1", "Stable mood with absence of sadness"),
    ("2", "Seeking opportunities and helping others"),
    ("3", "High self esteem"),
    ("4", "Feeling happy"),
    ("5", "Deeper understanding of guilt"),
    ("6", "Having a deeper interest and motivation in things"),
    ("7", "Seeking enjoyment"),
    ("8", "Reduced levels of anxiety and worries"),
    ("9", "Absence of suicidal thoughts and/or absence of thoughts of harming yourself"),

    ],

DEPRESSION_PHYSICAL_NEGATIVE_SYMPTOMS = [
    
    ("1", "Moving or speaking more slowly than usual"),
    ("2", "Changes in appetite or weight, usually decreased but sometimes increased"),
    ("3", "Constipation"),
    ("4", "Unexplained aches or pains"),
    ("5", "Lack of energy"),
    ("6", "Low sex drive"),
    ("7", "Changes to your menstrual cycle"),
    ("8", "Disturbed sleep"),
    
    ],

DEPRESSION_PHYSICAL_POSITIVE_SYMPTOMS = [
    
    ("1", "Moving or speaking more quickly than usual"),
    ("2", "Stable appetite and weight"),
    ("3", "Stable bowel motions"),
    ("4", "Absence of aches and pains"),
    ("5", "Increased energy"),
    ("6", "Increased sex drive"),
    ("7", "Stable menstrual cycle"),
    ("8", "Improved sleep"),
    
    ],

DEPRESSION_SOCIAL_NEGATIVE_SYMPTOMS = [
    
    ("1", "Avoiding contact with friends and taking part in fewer social activities"),
    ("2", "Neglecting your hobbies or interests"),
    ("3", "Having difficulties in your home, work or family life"),
    
    ],

DEPRESSION_SOCIAL_POSITIVE_SYMPTOMS = [
    
    ("1", "Taking part in regular social activities"),
    ("2", "Participating in hobbies and interests"),
    ("3", "Busy home, work and family life"),
    
    ]
