class depression(models.Model):
    DT1_Value = models.IntegerField()
    DT2_Value = models.IntegerField()
    DT3_Value = models.IntegerField()
    DT4_Value = models.IntegerField()
    DT5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')
