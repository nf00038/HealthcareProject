from django.apps import AppConfig


class DepressionConfig(AppConfig):
    name = 'Depression'
