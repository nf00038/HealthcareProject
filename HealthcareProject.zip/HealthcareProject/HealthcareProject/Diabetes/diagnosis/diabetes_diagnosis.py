class diabetes_A1CTest(models.Model):
    A1CT1_Value = models.IntegerField()
    A1CT2_Value = models.IntegerField()
    A1CT3_Value = models.IntegerField()
    A1CT4_Value = models.IntegerField()
    A1CT5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class diabetes_FPGTest(models.Model):
    FPG1_Value = models.IntegerField()
    FPG2_Value = models.IntegerField()
    FPG3_Value = models.IntegerField()
    FPG4_Value = models.IntegerField()
    FPG5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class diabetes_2HPGTest(models.Model):
    2HPG1_Value = models.IntegerField()
    2HPG2_Value = models.IntegerField()
    2HPG3_Value = models.IntegerField()
    2HPG4_Value = models.IntegerField()
    2HPG5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

