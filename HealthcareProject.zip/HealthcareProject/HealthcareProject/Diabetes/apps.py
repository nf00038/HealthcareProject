from django.apps import AppConfig


class DiabetesConfig(AppConfig):
    name = 'Diabetes'
