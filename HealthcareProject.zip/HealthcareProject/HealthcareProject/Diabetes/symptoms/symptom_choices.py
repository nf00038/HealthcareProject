DIABETES_NEGATIVE_SYMPTOMS = [
    
    ("1", "Peeing more than usual, particularly at night"),
    ("2", "Feeling thirsty all the time"),
    ("3", "Feeling very tired"),
    ("4", "Losing weight without trying to"),
    ("5", "Itching around your penis or vagina, or repeatedly getting thrush"),
    ("6", "Cuts or wounds, taking longer to heal"),
    ("7", "Blurred vision"),
    
    ],

DIABETES_POSITIVE_SYMPTOMS = [
    
    ("1", "1"),
    
    ]
