from django.apps import AppConfig


class Cervical_ScreeningConfig(AppConfig):
    name = 'Cervical_Screening'
