CERVICALSCREENING_NEGATIVE_SYMPTOMS = [
    
    ("1", "1")
    
    ],

CERVICALSCREENING_POSITIVE_SYMPTOMS = [
    
    ("1", "1")
    
    ]
