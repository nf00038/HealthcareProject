class HPVPrimaryScreening(models.Model):
    HPV1_Value = models.IntegerField()
    HPV2_Value = models.IntegerField()
    HPV3_Value = models.IntegerField()
    HPV4_Value = models.IntegerField()
    HPV5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')
