class asthma_symptom_control():

