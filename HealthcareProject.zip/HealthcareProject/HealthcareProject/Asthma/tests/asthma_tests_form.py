from django import forms

class AsthmaSymptomsForm(forms.Form):
    shortnessofbreath = forms.CharField(widget=forms.Choices()
    chesttightness = forms.CharField()
    troublesleeping = forms.CharField()
    whistlingsound = forms.CharField()
    wheezingsound = forms.CharField()

class AsthmaSituationsForm(forms.Form):
    ExerciseInduced = forms.CharField()
    OccupationalInduced = forms.CharField()
    AllergyInduced = forms.CharField()


