from django.apps import AppConfig


class AsthmaConfig(AppConfig):
    name = 'Asthma'
