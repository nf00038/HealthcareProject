from django import forms

class QualifyingServiceRuleset(forms.Form):
    Term = forms.CharField(max_length = 255)
    Description = forms.CharField(max_length=255)
    Definition = forms.CharField(max_length=255)
    Timeframe = forms.CharField(max_length=255)

