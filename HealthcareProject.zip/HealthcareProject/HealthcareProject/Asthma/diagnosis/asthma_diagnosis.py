from django.db import models
from Healthcare import diagnosis_choices 

class Spirometry(models.Model):
    FVC_Value1 = models.IntegerField()
    FVC_Value2 = models.IntegerField()
    FEV1_Value = models.IntegerField()
    FEV2_Value = models.IntegerField()
    FEV3_Value = models.IntegerField()
    FEV4_Value = models.IntegerField()
    FEV5_Value = models.IntegerField()
    FEV6_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class peak_flow(models.Model):  
    PF1_Value = models.IntegerField() 
    PF2_Value = models.IntegerField()
    PF3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class methacholine_challenge(models.Model):
    MCC1_Value = models.IntegerField()
    MCC2_Value = models.IntegerField()
    MCC3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class nitric_oxide_test(models.Model):
    NOT1_Value = models.IntegerField()
    NOT2_Value = models.IntegerField()
    NOT3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class imaging_tests(models.Model):
    IT1_Value = models.IntegerField()
    IT2_Value = models.IntegerField()
    IT3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class allergy_testing(models.Model):
    AT1_Value = models.IntegerField()
    AT2_Value = models.IntegerField()
    AT3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class sputum_eosinophillis(models.Model):
    SE1_Value = models.IntegerField()
    SE2_Value = models.IntegerField()
    SE3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class provocative_testing(models.Model):
    PT1_Value = models.IntegerField()
    PT2_Value = models.IntegerField()
    PT3_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')
  