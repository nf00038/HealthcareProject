from Healthcare.Asthma.models import QualifyingCriteria

def  GMS_Registration_Status_True(model=QualifyingCriteria, query=None, using=None, hints=None):
    if QualifyingCriteria.StartDate >= '2002' and QualifyingCriteria.EndDate <= '2018':
        return self.name

    if QualifyingCriteria.StartDate >= '2002' and (QualifyingCriteria.EndDate > QualifyingCriteria.Achv_Dat):
        return self.name

