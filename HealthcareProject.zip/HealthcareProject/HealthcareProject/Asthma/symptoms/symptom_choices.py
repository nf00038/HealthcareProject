ASTHMA_POSITIVE_SYMPTOM_CHOICES = [
    
    ("1", "No shortness of breath"),
    ("2", "No chest tightness"),
    ("3", "No trouble with sleeping"),
    ("4", "No whistling or wheezing"),
    ("5", "No coughing or wheezing attacks"),
    
    ]

ASTHMA_NEGATIVE_SYMPTOM_CHOICES = [
    
    ("1","Shortness of breath"),
    ("2","Chest Tightness"),
    ("3","Trouble Sleeping"),
    ("4","Whistling or wheezing"),
    ("5","Coughing or wheezing attacks"),
    
    ]

ASTHMA_FREQUENCY_CHOICES = [
    
    ("1", "Daily"),
    ("2", "Weekly"),
    ("3", "Fortnightly"),
    ("4", "Monthly"),
    ("5", "Quarterly"),
    ("6", "Bi-Annually"),
    ("7", "Annually"),
    
    ]