class Asthma_triggers(models.Model):
    def airborne_substances():
        x1 = 'pollen'
        x2 = 'dust mites'
        x3 = 'mold spores'
        x4 = 'pet dander'
        x5 = 'particles of cockroach waste'

    def respiratory_infections():
        x1 = 'common cold'

    def physical_activity():
        x1 = 'exercise_induced_asthma'

    def other_causes():
        x1 = 'cold air'
        x2 = 'air pollutants and irritants'
        x3 = 'certain medications including beta blockers, aspirin, ibuprofen (Advil, Motrin IB, Naproxen)'
        x4 = 'Strong emotions and stress'
        x5 = 'Sulfites and preservatives added to some types of food and beverages'
        x6 = 'Gastroesophageal reflux disease (GERD)'

    def risk_factors():
        x1 = 'having a blood relative'
        x2 = 'atopic dermatitis'
        x3 = 'allergic rhinitis'
        x4 = 'being overweight'

        x5 = 'being a smoker'
        x6 = 'exposure to secondhand smoke'
        x7 = 'exposure to exhaust fumes'
        x8 = 'exposure to occupational triggers'

   def complications():
       x1 = 'signs and symptoms that interfere with sleep'
       x2 = 'sick days from work or school during asthma flare-ups'
       x3 = 'permaneant narrowing of the bronchial tubes'
       x4 = 'emergency room visits'
       x5 = 'side effects from long term use of medications used to stabilize severe asthma'
