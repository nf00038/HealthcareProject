from django.db import models

class symptoms(models.Model):
    positive = models.CharField(max_length='255')
    Positive_Frequency = models.IntegerField()
    Positive_Frequency_Category = models.CharField(max_length='255')
    Date = models.DateField()
    Negative = models.CharField(max_length='255')
    Negative_Frequency = models.IntegerField()
    Negative_Frequency_Category = models.CharField(max_length='255')
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

    

