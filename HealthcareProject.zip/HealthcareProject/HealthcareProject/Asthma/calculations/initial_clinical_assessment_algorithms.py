from Asthma.symptoms.symptom_choices import symptom_choices as x1

class clinical_history():

    x1 = 

    def activityone():

    def activitytwo():

    def activitythree():
