from django.shortcuts import render
from django.http import HttpResponse
from django.core.mail import send_mail
from . Forms import QualifyingServiceRuleset

# Create your views here.

def GMS_Registration_Status(request):
    form = QualifyingServiceRuleset(request.POST or None)
    if form.is_valid():
        form.save()
        return HttpResponseRedirect('/Completed')
    context = {
        'form': form
        }
    return render(request, 'GMSRegistrationStatus.html', context)

def Home(request):
    return render(request,'Asthma/Home.html')