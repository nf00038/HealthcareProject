from django.db import models

class Patients(models.Model):
    NHS_No = models.IntegerField()
    Surname = models.DateField()
    Initials = models.DateField()
    Registration_Date = models.DateField()
    Deregistration_Date = models.DateField()
    ACHV_Date = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

    def __str__(self):
        return self.NHS_No
