from django.db import models

class QualifyingServiceRuleset(models.Model):
    Term = models.CharField(max_length=255)
    Description = models.CharField(max_length=255)
    Definition = models.CharField(max_length=255)
    Timeframe = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

class QualifyingService(models.Model):
    QS_Name = models.CharField(max_length=255)
    Start_Date = models.DateField()
    End_Date = models.DateField()
    Period = models.IntegerField()
    Data_Extract_Frequency = models.IntegerField()
    Payment_Period = models.IntegerField()
    PPSD = models.DateField()
    PPED = models.DateField()
    PPED_3Months = models.DateField()
    PPED_12Months = models.DateField()
    ACHV_Date = models.DateField()
    Reporting_Period = models.DateField()
    RPSD = models.DateField()
    RPED = models.DateField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)

    def __str__(self):
        return self.name



class Admissions(models.Model):
    #User = models.ForeignKey()
    date_of_admission = models.DateField()
    patient_age = models.CharField()
    patient_gender = models.CharField()
    patient_education = models.CharField()
    patient_postcode = models.CharField()
    patient_temperature = models.CharField()
    patient_heartrate = models.CharField()
    created = models.DateTimeField(auto_now_add=True, editable=False, null=False, blank=False)
    last_modified = models.DateTimeField(auto_now=True, editable=False, null=False, blank=False)


