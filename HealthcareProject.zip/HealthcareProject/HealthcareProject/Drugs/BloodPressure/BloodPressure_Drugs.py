
diuretics_choices = [
    
    ("1", "chlorthalidone"),
    ("2", "chlorothiazide"),
    ("3", "hydrochlorothiazide"),
    ("4", "indapamide"),
    ("5", "metolazone"),
    
    ],

potassium_sparing_diuretics = [
    
    ("1", "amiloride hydrochloride"),
    ("2", "spironolactone"),
    ("3", "triamterene"),
    
    ],

loop_diuretics = [
    
    ("1", "furosemide"),
    ("2", "bumetanide"),

    ],

combination_diuretics = [
    
    ("1", "amiloride hydrochloride + hydrochlorothiazide"),
    ("2", "spironolactone + hydrochlorothiazide"),
    ("3", "triamterene + hydrochlorothiazide"),

    ],

beta_blockers = [
    
    ("1", "acebutolol"),
    ("2", "atenolol"),
    ("3", "betaxolol"),
    ("4", "bisoprolol fumarate"),
    ("5", "carteolol hydrochloride"),
    ("6", "metoprolol tartrate"),
    ("7", "metoprolol succinate"),
    ("8", "nadolol"),
    ("9", "penbutolol sulfate"),
    ("10", "pindolol"),
    ("11", "propranolol hydrochloride"),
    ("12", "solotol hydrochloride"),
    ("13", "timolol maleate"),
    
    ],

combination_beta_blocker_diuretic = [
    
    ("1", "hydrochlorothiazide and bisoprolol")
    
    ],

ace_inhibitors = [
    
    ("1", "benazepril hydrochloride"),
    ("2", "captopril"),
    ("3", "enalapril maleate"),
    ("4", "fosinopril sodium"),
    ("5", "lisinopril"),
    ("6", "moexipril"),
    ("7", "perindopril"),
    ("8", "quinapril hydrochloride"),
    ("9", "ramipril"),
    ("10", "trandolapril"),

    ],

angiotensin_II_receptor_blockers = [
    
    ("1", "candesartan"),
    ("2", "eprosartan mesylate"),
    ("3", "irbesarten"),
    ("4", "losartan potassium"),
    ("5", "telmisartan"),
    ("6", "valsartan"),


    ],

calcium_channel_blockers = [
    
    ("1", "amlodipine besylate"),
    ("2", "bepridil"),
    ("3", "diltiazem hydrochloride"),
    ("4", "felodipine"),
    ("5", "isradipine"),
    ("6", "nicardipine"),
    ("7", "nifedipine"),
    ("8", "nisoldipine"),
    ("9", "verapamil hydrochloride"),
    
    ],

Alpha_blockers = [
    
    ("1", "doxazosin mesylate"),
    ("2", "prazosin hydrochloride"),
    ("3", "terazosin hydrochloride"),

    ],

Alpha_2_Receptor_antagonists = [
    
    ("1", "methyldopa")

    ],

combined_Alpha_and_beta_blockers = [
    
    ("1", "carvedilol"),
    ("2", "labetalol hydrochloride"),
    
    ],


central_agonists = [
    
    ("1", "alpha methyldopa"),
    ("2", "clonidine hydrochloride"),
    ("3", "guanabenz acetate"),
    ("4", "guanfacine hydrochloride")

    ],

peripheral_adregenic_inhibitors = [
    
    ("1", "guanadrel"),
    ("2", "guanethidine monosulfate"),
    ("3", "reserpine"),

    ],

blood_vessel_dilators = [
    
    ("1", "hydralazine hydrochloride"),
    ("2", "minoxidil")

    ]