class components(models.Model):
    Name =  models.CharField(max_length=255)
    Description = models.CharField(max_length=255)
    Quantity = models.IntegerField()
    Measurement = models.CharField(max_length=255)

