Beta_Blocker_Drugs = [
    
    ("1", "Atenolol"),
    ("2", "Bisoprolol"),
    ("3", "Carvedilol"),
    ("4", "Metoprolol"),
    ("5", "Nadolol"),
    ("6", "Propanolol"),
    ("7", "Timolol"),

    ],

Calcium_Channel_Blocker = [
    
    ("1", "Dilitiazem"),
    ("2", "Verapamil"),
    ("3", "Digoxin"),

    ],

Heart_Rhythm_Controlling_Medications = [
    
    ("1", "Flecainide"),
    ("2", "Propafenone"),
    ("3", "Quinidine"),

    ]

Potassium_channel_Blockers = [

    ("1", "Amiodarone"),
    ("2", "Sotalol"),
    ("3", "Dofetilide"),

    ]