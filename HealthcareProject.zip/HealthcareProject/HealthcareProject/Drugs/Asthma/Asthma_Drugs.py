BIOLOGICS_CHOICES = [
    
    ("1","omalizumab"),
    ("2","mepolizumab"),
    ("3", "reslizumab"),
    ("4", "benralizumab"),
    ("5", "dupilumab")

    ]

Omalizumab_INDICATIONS = [
    
    ("1", "Prophylaxis of severe persistent allergic asthma"),
    ("2", "Add-on therapy for chronic spontaneous urticaria in patients who have had an inadequate response to H1 antihistamine treatment")

    ]

Omalizumab_DOSES = [
    
    ("1", "Dose according to immunoglobulin E concentration and body-weight (consult product literature)."),
    ("2", "300 mg every 4 weeks")
    ]

mepolizumab_INDICATIONS = [
    
    ("1",  "Mepolozumab is an interleukin-5 antagonist monoclonal antibody indicated for addon maintenance treatment of patients with severe asthma aged 12 years or older and with an eosinophillic phenotype.")

    ]

mepolizumab_DOSES = [

    (1, "100mg administered subcutaneously every 4 weeks")

    ]

reslizumab_INDICATIONS = [
    
    ("1", "By Intravenous Infusion. Do not administer as an intraveneous push or bolus.")

    ]

reslizumab_DOSES = [

    ("1", "3mg/kg once every four weeks by intraveneous infusion over 20-50 minutes.")

    ]

benralizumab_INDICATIONS = [
    
    ("1", "By subcutaneous injection")
    ]

benralizumab_DOSES = [

    ("1", "Initially 30mg every 4 weeks for the first three doses, then maintenance 30mg every 8 weeks, to be administered into the thigh, abdomen or upper abdomen")
    
    ]

dupilumab_INDICATIONS = [
    
    ("1", "Subcutaneous injection")

    ]

dupilumab_DOSES = [

    ("1", "150mg/L Solution in a pre-filled syringe with needle shield (PFS-S) or pre-filled syringe.")
    ("2", "175mg/L pre-filled syringe with needle shield (PFS-S).")

    ]
