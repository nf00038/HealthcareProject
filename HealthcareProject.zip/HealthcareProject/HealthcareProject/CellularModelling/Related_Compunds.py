class Related_Compound(models.Model):
    CompoundID = models.CharField()
    Name = models.CharField()
    MolecularFormula = models.CharField()
    MolecularWeight = moels.CharField()



