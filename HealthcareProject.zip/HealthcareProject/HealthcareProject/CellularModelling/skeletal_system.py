class skeletal_System():

    def skeletal_structure():

        def CompactBone():

        def CancellousBone():

    def bone_development():

        def Intramembranous():

        def Endochondral Ossification():

    def bone_growth():

    def classification_of_bones():

        def long_bones():

        def short_bones():

        def flat_bones():

        def irregular_bones():

    def divisions_of_skeleton():

        def axial_skeleton():

            def cranialbones():

            def Facialbones():

            def AuditoryOssicles():

            def VertebralColumn():

            def ThoracicCage()

        def appendicular_skeleton():

            def PectoralGirdles():

            def UpperExtremeity():

            def PelvicGurdle():

            def LowerExtremity():
