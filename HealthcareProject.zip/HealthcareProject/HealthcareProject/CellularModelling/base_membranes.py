class base_cell_membranes(models.Model):
    Epithelial_Membranes = models.IntegerField()
    Mucuous_Membranes = models.IntegerField()
    Serous_Membranes = models.IntegerField()
    Connective_Tissue_Membranes = models.IntegerField()
    Synovial_Membranes = models.IntegerField()

class cell_membranes():

    def Membranes():

        @property
        def Epithelial_Membranes():

        @property
        def Mucuous_Membranes():

        @property
        def Serous_Membranes():
        
        @property
        def Connective_Tissue_Membranes():

        @property
        def Synovial_Membranes():

        @property
        def Meninges():



