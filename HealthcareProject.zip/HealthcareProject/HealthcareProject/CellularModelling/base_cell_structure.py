class base_cell_structure(models.Model:

    Nucleus = models.IntegerField()
    NuclearMembrane = models.IntegerField()
    Chromatin = models.IntegerField()
    DNA = models.IntegerField()
    Nucleolus = models.IntegerField()
    RNA = models.IntegerField()
    Cytoplasm = models.IntegerField()
    Organelles = models.IntegerField()
    CytoplasmicOrganelles = models.IntegerField()
    Mitochondron = models.IntegerField()
    Ribosomes = models.IntegerField()
    EndoplasmicReticulum = models.IntegerField()
    GolgiApparatus = models.IntegerField()
    Lysosomes = models.IntegerField()
    CellFunction = models.IntegerField()
    ExtracellularMaterial = models.IntegerField()
    IntracellularMaterial = models.IntegerField()
    Diffusion = models.IntegerField()
    Osmosis = models.IntegerField()
    Filtration = models.IntegerField()
    ActiveTransport = models.IntegerField()
    Endocytosis = models.IntegerField()
    Exocytosis = models.IntegerField()
    CellDivision = models.IntegerField()
    Mitosis = models.IntegerField()
    Prophase = models.IntegerField()
    Metaphase = models.IntegerField()
    Anaphase = models.IntegerField()
    Telophase = models.IntegerField()
    Meiosis = models.IntegerField()
    Cytokineses = models.IntegerField()

class cell_structure():

    def CellMembrane():
    
        @property
        def Cytoplasm():

            @property
            def Chromatin():

            @property
            def Nucleus():
            
            @property
            def Nucleolus():

            @property
            def Ribosomes():

            @property
            def Mitochondrion():

            @property
            def EndoplasmicReticulum():

            @property
            def Microtubles():

            @property
            def Cenrioles():

            @property
            def Lysosome():

