from django.apps import AppConfig


class CellularModellingConfig(AppConfig):
    name = 'CellularModelling'
