class Periodic_Table(models.Model):
    AtomicNumber = models.IntegerField()
    Symbol = models.CharField()
    Name = models.CharField()
    Weight = models.IntegerField()

