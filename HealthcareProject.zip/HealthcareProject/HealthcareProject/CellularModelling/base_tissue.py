class base_body_tissue():
    epithelial tissue = models.IntegerField()
    connective_tissue = models.IntegerField()
    Muscle_tissue = models.IntegerField()
    Nervous_Tissue = models.IntegerField()

class body_tissue():

    def Tissues():

        @property
        def epithelial tissue():

        @property
        def connective_tissue():
        
        @property
        def Muscle_tissue():

        @property
        def Nervous_Tissue():


