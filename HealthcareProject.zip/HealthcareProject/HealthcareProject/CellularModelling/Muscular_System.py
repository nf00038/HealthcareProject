class MuscularSystem():

    def Epymysium():

    def Tendon():

    def Perimysium():

    def BloodVessel():

    def MuscleFiber():

    def Fascicle():

    def Endomysium():

    def Bone():

class MuscleTypes():

    def SkeletalMuscle():

    def SmoothMuscle():

    def CardiacMuscle():

class MuscleGroups():

    def Size():

    def Shape():

    def DirectionofFibers():

    def Location():

    def NumberofOrigins():

    def OriginandINsertion():

    def Action():