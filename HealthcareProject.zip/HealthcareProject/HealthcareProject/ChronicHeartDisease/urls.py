from django.contrib import admin
from django.conf.urls import include
from django.conf.urls import url
from . import views

app_name = "ChronicHeartDisease"

urlpatterns = [
    url(r'^admin/', admin.site.urls),
    url(r'^$', views.Home, name='Home'),
]