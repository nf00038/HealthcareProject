from django.apps import AppConfig


class Chronic_Heart_DiseaseConfig(AppConfig):
    name = 'Chronic_Heart_Disease'
