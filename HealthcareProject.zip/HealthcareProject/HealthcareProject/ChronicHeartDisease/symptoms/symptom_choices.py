CHD_NEGATIVE_SYMPTOMS = [
    
    ("1", "Shortness of Breath"),
    ("2", "Fatigue and Weakness"),
    ("3", "Swelling in your legs, ankles and feet"),
    ("4", "Rapid or irregular heartbeat"),
    ("5", "Reduced ability to exercise"),
    ("6", "Persistent cough or wheezing with white or pink tinged phlegm"),
    ("7", "Increased need to urinate at night"),
    ("8", "Swelling of your abdomen"),
    ("9", "Very rapid weight gain from fluid retention"),
    ("10", "Lack of appetite and nausea"),
    ("11", "Difficulty concentrating or decreased alertness"),
    ("12", "Sudden, severe shortness of breath, and coughing up pink, foamy mucus"),
    ("13", "Chest pain if your heart failure is caused by a heart attack"),
    
    ],

CHD_POSITIVE_SYMPTOMS = [
    
    ("1", "No shortness of breath"),
    ("2", "No fatigue and weakness"),
    ("3", "No swelling in your legs, ankles and feet"),
    ("4", "Rapid or irregular heartbeat"),
    ("5", "Reduced ability to exercise"),
    ("6", "Persistent cough or wheezing with white or pink tinged phlegm"),
    
    ]