class dementia_diet(models.Model):
    Diet1_Value = models.IntegerField()
    Diet2_Value = models.IntegerField()
    Diet3_Value = models.IntegerField()
    Diet4_Value = models.IntegerField()
    Diet5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_nutrition(models.Model):
    Nutrition1_Value = models.IntegerField()
    Nutrition2_Value = models.IntegerField()
    Nutrition3_Value = models.IntegerField()
    Nutrition4_Value = models.IntegerField()
    Nutrition5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_alcohol(models.Model):
    Alcohol1_Value = models.IntegerField()
    Alcohol2_Value = models.IntegerField()
    Alcohol3_Value = models.IntegerField()
    Alcohol4_Value = models.IntegerField()
    Alcohol5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_medicationreview(models.Model):
    MR1_Value = models.IntegerField()
    MR2_Value = models.IntegerField()
    MR3_Value = models.IntegerField()
    MR4_Value = models.IntegerField()
    MR5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_bloodpressure(models.Model):
    BP1_Value = models.IntegerField()
    BP2_Value = models.IntegerField()
    BP3_Value = models.IntegerField()
    BP4_Value = models.IntegerField()
    BP5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_temperature(models.Model):
    T1_Value = models.IntegerField()
    T2_Value = models.IntegerField()
    T3_Value = models.IntegerField()
    T4_Value = models.IntegerField()
    T5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_pulse(models.Model):
    P1_Value = models.IntegerField()
    P2_Value = models.IntegerField()
    P3_Value = models.IntegerField()
    P4_Value = models.IntegerField()
    P5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_heartlisten(models.Model):
    HL1_Value = models.IntegerField()
    HL2_Value = models.IntegerField()
    HL3_Value = models.IntegerField()
    HL4_Value = models.IntegerField()
    HL5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_lunglisten(models.Model):
    LL1_Value = models.IntegerField()
    LL2_Value = models.IntegerField()
    LL3_Value = models.IntegerField()
    LL4_Value = models.IntegerField()
    LL5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_bloodsamples(models.Model):
    BS1_Value = models.IntegerField()
    BS2_Value = models.IntegerField()
    BS3_Value = models.IntegerField()
    BS4_Value = models.IntegerField()
    BS5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_urinesamples(models.Model):
    US1_Value = models.IntegerField()
    US2_Value = models.IntegerField()
    US3_Value = models.IntegerField()
    US4_Value = models.IntegerField()
    US5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_neurologicalexam(models.Model):
    NE1_Value = models.IntegerField()
    NE2_Value = models.IntegerField()
    NE3_Value = models.IntegerField()
    NE4_Value = models.IntegerField()
    NE5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_mentalfunctiontests(models.Model):
    MF1_Value = models.IntegerField()
    MF2_Value = models.IntegerField()
    MF3_Value = models.IntegerField()
    MF4_Value = models.IntegerField()
    MF5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_moodassessment(models.Model):
    MA1_Value = models.IntegerField()
    MA2_Value = models.IntegerField()
    MA3_Value = models.IntegerField()
    MA4_Value = models.IntegerField()
    MA5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class dementia_brainimaging(models.Model):
    BI1_Value = models.IntegerField()
    BI2_Value = models.IntegerField()
    BI3_Value = models.IntegerField()
    BI4_Value = models.IntegerField()
    BI5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

