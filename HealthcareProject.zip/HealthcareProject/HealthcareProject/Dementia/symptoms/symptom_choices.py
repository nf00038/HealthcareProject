Dementia_Negative_Symptoms = [
    
    ("1", "Memory loss"),
    ("2", "Difficulty performing familiar tasks"),
    ("3", "Problems with language"),
    ("4", "Disorientation to time and place"),
    ("5", "Poor or decreased judgement"),
    ("6", "Problems with keeping track of things"),
    ("7", "Misplacing things"),
    ("8", "Changes in mood or behaviour"),
    
    ],

Dementia_Positive_Symptoms = [
    
    ("1", "1")

    ]
