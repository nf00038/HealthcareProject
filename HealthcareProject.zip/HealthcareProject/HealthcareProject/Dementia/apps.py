from django.apps import AppConfig


class DementiaConfig(AppConfig):
    name = 'Dementia'
