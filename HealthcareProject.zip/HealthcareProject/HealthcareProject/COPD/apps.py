from django.apps import AppConfig


class COPDConfig(AppConfig):
    name = 'COPD'
