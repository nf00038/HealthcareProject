class Spirometry(models.Model):
    S1_Test = models.IntegerField()
    S2_Test = models.IntegerField()
    S3_Test = models.IntegerField()
    S4_Test = models.IntegerField()
    S5_Test = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class chest_xray(models.Model):
    CX1_Value = models.IntegerField()
    CX2_Value = models.IntegerField()
    CX3_Value = models.IntegerField()
    CX4_Value = models.IntegerField()
    CX5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class Oximetry(models.Model):
    O1_Value = models.IntegerField()
    O2_Value = models.IntegerField()
    O3_Value = models.IntegerField()
    O4_Value = models.IntegerField()
    O5_Value = models.IntegerField()
    Date_Created = models.DateField(auto_now_add='True')
    Date_Updated = models.DateField(auto_now='True')

class Other_Tests(models.Model):
    OT1_Value = models.IntegerField()
    OT2_Value = models.IntegerField()
    OT3_Value = models.IntegerField()
    OT4_Value = models.IntegerField()
    OT5_Value = models.IntegerField()


