COPD_NEGATIVE_SYMPTOMS = [
    
    ("1", "Increased breathlessness"),
    ("2", "A persistent chesty cough with phlegm that does not go away"),
    ("3", "Frequent chest infections"),
    ("4", "Persistent wheezing"),
    
    ],

COPD_POSITIVE_SYMPTOMS = [
    
    ("1", "1"),

    ]
